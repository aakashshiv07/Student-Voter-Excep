﻿Public Class Form1
    ' Button click event handler
    Private Sub btnCheckEligibility_Click(sender As Object, e As EventArgs) Handles btnCheckEligibility.Click
        Try
            ' Convert the text entered in txtAge to an integer
            Dim age As Integer = Convert.ToInt32(txtAge.Text)

            ' Check if the age is valid (non-negative)
            If age < 0 Then
                Throw New ArgumentException("Age cannot be negative.")
            End If

            ' Check if the user is eligible to vote (18 or older)
            If age >= 18 Then
                lblResult.Text = "You are eligible to vote."
            Else
                lblResult.Text = "You are not eligible to vote."
            End If

        Catch ex As FormatException
            ' Handle non-numeric input
            MessageBox.Show("Please enter a valid numeric age.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

        Catch ex As ArgumentException
            ' Handle invalid age (e.g., negative numbers)
            MessageBox.Show(ex.Message, "Age Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

        Catch ex As Exception
            ' Handle any other unforeseen errors
            MessageBox.Show("An unexpected error occurred: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
End Class
