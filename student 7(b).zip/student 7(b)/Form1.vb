﻿Public Class Form1

    ' This event triggers when the "Check Status" button is clicked
    Private Sub btnCheckStatus_Click(sender As Object, e As EventArgs) Handles btnCheckStatus.Click
        Try
            ' Retrieve the student ID from the textbox
            Dim studentID As String = txtStudentID.Text

            ' Check if the ID is empty
            If String.IsNullOrEmpty(studentID) Then
                Throw New ArgumentException("Student ID cannot be empty.")
            End If

            ' Simulate checking the student's enrollment status
            ' Here we are using a simple check. In a real application, this could be a database query.
            Dim enrolledStudentIDs As New List(Of String) From {"12345", "67890", "54321"}

            If enrolledStudentIDs.Contains(studentID) Then
                lblResult.Text = "Student is enrolled."
            Else
                lblResult.Text = "Student is not enrolled."
            End If

        Catch ex As ArgumentException
            ' Handle case where the student ID is empty
            MessageBox.Show(ex.Message, "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

        Catch ex As Exception
            ' Handle any other unexpected errors
            MessageBox.Show("An error occurred: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

End Class
